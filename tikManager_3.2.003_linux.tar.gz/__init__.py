__author__ = "Arda Kutlu"
__copyright__ = "Copyright 2019, Tik Manager"
__credits__ = []
__license__ = "GPL"
__maintainer__ = "Arda Kutlu"
__email__ = "ardakutlu@gmail.com"
