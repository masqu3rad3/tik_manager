function tikUI(){
    var bat = new File("C://Users//kutlu//Repositories//tik_manager//tik_manager//bin//SmPhotoshop.exe");
    bat.execute();
}
function tikSaveVersion(){
    var ver = new File("C://Users//kutlu//Repositories//tik_manager//tik_manager//bin//saveVersion.vbs");
    ver.execute();
}
